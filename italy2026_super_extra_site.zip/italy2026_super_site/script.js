// Countdown target: Venice arrival. Change this if your arrival time changes.
const target = new Date('2026-06-27T09:55:00+02:00').getTime();
const ids = ['days','hours','minutes','seconds'].map(id => document.getElementById(id));
function tick(){
  const diff = Math.max(0, target - Date.now());
  const d = Math.floor(diff / 86400000);
  const h = Math.floor(diff / 3600000) % 24;
  const m = Math.floor(diff / 60000) % 60;
  const s = Math.floor(diff / 1000) % 60;
  [d,h,m,s].forEach((v,i)=> ids[i].textContent = String(v).padStart(2,'0'));
}
tick(); setInterval(tick,1000);

const observer = new IntersectionObserver(entries => entries.forEach(e => {
  if(e.isIntersecting) e.target.classList.add('show');
}), {threshold:.15});
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

function burst(){
  for(let i=0;i<90;i++){
    const piece=document.createElement('i');
    piece.textContent=['🇮🇹','✨','🍝','🍦','💍','🚢'][Math.floor(Math.random()*6)];
    piece.style.position='fixed'; piece.style.left=Math.random()*100+'vw'; piece.style.top='-40px';
    piece.style.fontStyle='normal'; piece.style.fontSize=(18+Math.random()*24)+'px'; piece.style.zIndex=1000;
    piece.style.transition=(2+Math.random()*2)+'s linear'; document.body.appendChild(piece);
    requestAnimationFrame(()=>{piece.style.transform=`translateY(${110+Math.random()*30}vh) rotate(${Math.random()*720}deg)`; piece.style.opacity='0'});
    setTimeout(()=>piece.remove(),4200);
  }
}
document.getElementById('confettiBtn').addEventListener('click', burst);
setTimeout(()=>document.querySelector('.stop')?.classList.add('active'), 600);
