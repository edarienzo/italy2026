# italy2026

A cinematic Darienzo family Italy 2026 countdown site.

## Edit countdown
Open `script.js` and change:

```js
const target = new Date('2026-06-27T09:55:00+02:00').getTime();
```

## GitHub Pages
Upload `index.html`, `styles.css`, `script.js`, and this `README.md` to the repository root.
